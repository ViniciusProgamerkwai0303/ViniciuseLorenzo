
//alert("Testando o script!");

var nome = prompt("Qual o seu nome? ");

var sobrenome = prompt("Qual o seu sobrenome? ");

console.log("Olá "+nome+" "+sobrenome);

//saída do DOM
document.write("<h1>Bem vindo "+nome+" "+sobrenome+"</h1>");
document.write("Steve através de javascript");

document.write('<img src="https://sujeitoprogramador.com/steve.png" alt="foto do Steve" />');