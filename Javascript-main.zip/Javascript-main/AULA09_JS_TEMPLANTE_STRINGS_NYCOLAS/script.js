let nome = "Nycolas";
let sobreNome = "Marques";
let idade = 16;

let mensagem = "Meu nome é "+nome+" "+sobreNome+" e minha idade é "+idade+" anos."
console.log(mensagem);

let mensagem2= `Meu nome é ${nome} ${sobreNome} e minha idade é ${idade} anos.`
console.log(mensagem2)